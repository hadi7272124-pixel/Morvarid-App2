package com.mervarid.processviewer.model

data class Chapter(
    val id: String,
    val title: String,
    val file: String,
    val startPage: Int,
    val endPage: Int,
    val pageCount: Int
)
