package com.mervarid.processviewer

import android.content.Context
import com.mervarid.processviewer.model.Chapter
import com.mervarid.processviewer.model.DictionaryEntry
import com.mervarid.processviewer.model.GuideSection
import org.json.JSONArray

object DataRepository {

    private fun readAsset(context: Context, name: String): String {
        return context.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    fun loadChapters(context: Context): List<Chapter> {
        val json = JSONArray(readAsset(context, "chapters_manifest.json"))
        val list = mutableListOf<Chapter>()
        for (i in 0 until json.length()) {
            val o = json.getJSONObject(i)
            list.add(
                Chapter(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    file = o.getString("file"),
                    startPage = o.getInt("startPage"),
                    endPage = o.getInt("endPage"),
                    pageCount = o.getInt("pageCount")
                )
            )
        }
        return list
    }

    fun loadGuideSections(context: Context): List<GuideSection> {
        val json = JSONArray(readAsset(context, "process_guide.json"))
        val list = mutableListOf<GuideSection>()
        for (i in 0 until json.length()) {
            val o = json.getJSONObject(i)
            list.add(
                GuideSection(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    body = o.getString("body")
                )
            )
        }
        return list
    }

    fun loadDictionary(context: Context): List<DictionaryEntry> {
        val json = JSONArray(readAsset(context, "dictionary.json"))
        val list = mutableListOf<DictionaryEntry>()
        for (i in 0 until json.length()) {
            val o = json.getJSONObject(i)
            list.add(
                DictionaryEntry(
                    en = o.getString("en"),
                    fa = o.getString("fa"),
                    category = o.optString("category", ""),
                    note = o.optString("note", "")
                )
            )
        }
        return list
    }
}
