package com.mervarid.processviewer.model

data class DictionaryEntry(
    val en: String,
    val fa: String,
    val category: String,
    val note: String = ""
)
