package com.mervarid.processviewer.model

data class GuideSection(
    val id: String,
    val title: String,
    val body: String
)
