package com.mervarid.processviewer.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mervarid.processviewer.DataRepository
import com.mervarid.processviewer.R
import com.mervarid.processviewer.adapter.ChapterAdapter

class ChaptersFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val chapters = DataRepository.loadChapters(requireContext())
        recyclerView.adapter = ChapterAdapter(chapters) { chapter ->
            val intent = Intent(requireContext(), PdfViewerActivity::class.java)
            intent.putExtra(PdfViewerActivity.EXTRA_FILE, chapter.file)
            intent.putExtra(PdfViewerActivity.EXTRA_TITLE, chapter.title)
            startActivity(intent)
        }
    }
}
