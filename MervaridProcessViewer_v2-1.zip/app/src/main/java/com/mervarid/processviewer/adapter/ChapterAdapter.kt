package com.mervarid.processviewer.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mervarid.processviewer.R
import com.mervarid.processviewer.model.Chapter

class ChapterAdapter(
    private val items: List<Chapter>,
    private val onClick: (Chapter) -> Unit
) : RecyclerView.Adapter<ChapterAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val number: TextView = view.findViewById(R.id.item_number)
        val title: TextView = view.findViewById(R.id.item_title)
        val subtitle: TextView = view.findViewById(R.id.item_subtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_list_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val chapter = items[position]
        holder.number.text = (position + 1).toString()
        holder.title.text = chapter.title
        holder.subtitle.text = "${chapter.pageCount} صفحه · ص ${chapter.startPage} تا ${chapter.endPage}"
        holder.itemView.setOnClickListener { onClick(chapter) }
    }

    override fun getItemCount(): Int = items.size
}
