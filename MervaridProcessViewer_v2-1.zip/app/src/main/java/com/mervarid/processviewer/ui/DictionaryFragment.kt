package com.mervarid.processviewer.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mervarid.processviewer.DataRepository
import com.mervarid.processviewer.R
import com.mervarid.processviewer.adapter.DictionaryAdapter
import com.mervarid.processviewer.model.DictionaryEntry

class DictionaryFragment : Fragment() {

    private lateinit var allEntries: List<DictionaryEntry>
    private lateinit var adapter: DictionaryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_dictionary, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        allEntries = DataRepository.loadDictionary(requireContext())

        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = DictionaryAdapter(allEntries)
        recyclerView.adapter = adapter

        val searchBox = view.findViewById<EditText>(R.id.search_box)
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filter(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            adapter.updateData(allEntries)
            return
        }
        val filtered = allEntries.filter {
            it.en.contains(trimmed, ignoreCase = true) ||
                it.fa.contains(trimmed, ignoreCase = true) ||
                it.category.contains(trimmed, ignoreCase = true)
        }
        adapter.updateData(filtered)
    }
}
