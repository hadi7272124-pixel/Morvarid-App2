package com.mervarid.processviewer.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mervarid.processviewer.R
import com.mervarid.processviewer.model.GuideSection

class GuideAdapter(
    private val items: List<GuideSection>,
    private val onClick: (GuideSection) -> Unit
) : RecyclerView.Adapter<GuideAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val number: TextView = view.findViewById(R.id.item_number)
        val title: TextView = view.findViewById(R.id.item_title)
        val subtitle: TextView = view.findViewById(R.id.item_subtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_list_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val section = items[position]
        holder.number.text = (position + 1).toString()
        holder.title.text = section.title
        val preview = section.body.take(70).replace("\n", " ")
        holder.subtitle.text = "$preview..."
        holder.itemView.setOnClickListener { onClick(section) }
    }

    override fun getItemCount(): Int = items.size
}
