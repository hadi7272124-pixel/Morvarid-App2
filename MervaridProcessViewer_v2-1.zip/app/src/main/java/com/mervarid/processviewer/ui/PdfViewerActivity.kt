package com.mervarid.processviewer.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.github.barteksc.pdfviewer.PDFView
import com.mervarid.processviewer.R

class PdfViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_FILE = "extra_file"
        const val EXTRA_TITLE = "extra_title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf_viewer)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val file = intent.getStringExtra(EXTRA_FILE) ?: return
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        supportActionBar?.title = title

        val pdfView = findViewById<PDFView>(R.id.pdf_view)
        pdfView.fromAsset(file)
            .enableSwipe(true)
            .swipeHorizontal(false)
            .enableDoubletap(true)
            .defaultPage(0)
            .enableAntialiasing(true)
            // Allow deep pinch-zoom so small labels and equipment tags on the
            // process diagrams can be read clearly.
            .minZoom(1f)
            .midZoom(4f)
            .maxZoom(30f)
            .spacing(4)
            .load()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
