package com.mervarid.processviewer.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mervarid.processviewer.R
import com.mervarid.processviewer.model.DictionaryEntry

class DictionaryAdapter(
    private var items: List<DictionaryEntry>
) : RecyclerView.Adapter<DictionaryAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val en: TextView = view.findViewById(R.id.item_en)
        val fa: TextView = view.findViewById(R.id.item_fa)
        val category: TextView = view.findViewById(R.id.item_category)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_dictionary, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = items[position]
        holder.en.text = entry.en
        holder.fa.text = entry.fa
        holder.category.text = entry.category
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<DictionaryEntry>) {
        items = newItems
        notifyDataSetChanged()
    }
}
